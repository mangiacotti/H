﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H1
{
    public class cSkylineCountryClub
    {
        public double[] mBlueTeesLat = new double[19];
        public double[] mBlueTeesLong = new double[19];

        public double[] mFrontGreenLat = new double[19];
        public double[] mFrontGreenLong = new double[19];

        public double[] mMidGreenLat = new double[19];
        public double[] mMidGreenLong = new double[19];

        public double[] mRearGreenLat = new double[19];
        public double[] mRearGreenLong = new double[19];

        //Default ctor
        public cSkylineCountryClub()
        {
            //Initialize Blue Tees
            mBlueTeesLat[1] = 32.327983;
            mBlueTeesLat[2] = 32.330513;
            mBlueTeesLat[3] = 32.3304;
            mBlueTeesLat[4] = 32.327871;
            mBlueTeesLat[5] = 32.330542;
            mBlueTeesLat[6] = 32.327043;
            mBlueTeesLat[7] = 32.323945;
            mBlueTeesLat[8] = 32.32521;
            mBlueTeesLat[9] = 32.327531;
            mBlueTeesLat[10] = 32.32775;
            mBlueTeesLat[11] = 32.328922;
            mBlueTeesLat[12] = 32.332307;
            mBlueTeesLat[13] = 32.329503;
            mBlueTeesLat[14] = 32.328458;
            mBlueTeesLat[15] = 32.325136;
            mBlueTeesLat[16] = 32.324057;
            mBlueTeesLat[17] = 32.324765;
            mBlueTeesLat[18] = 32.325621;

            mBlueTeesLong[1] = -110.882471;
            mBlueTeesLong[2] = -110.884202;
            mBlueTeesLong[3] = -110.885944;
            mBlueTeesLong[4] = -110.887985;
            mBlueTeesLong[5] = -110.890888;
            mBlueTeesLong[6] = -110.889538;
            mBlueTeesLong[7] = -110.890331;
            mBlueTeesLong[8] = -110.888355;
            mBlueTeesLong[9] = -110.884531;
            mBlueTeesLong[10] = -110.881061;
            mBlueTeesLong[11] = -110.878882;
            mBlueTeesLong[12] = -110.878022;
            mBlueTeesLong[13] = -110.87708;
            mBlueTeesLong[14] = -110.877139;
            mBlueTeesLong[15] = -110.877879;
            mBlueTeesLong[16] = -110.881168;
            mBlueTeesLong[17] = -110.886297;
            mBlueTeesLong[18] = -110.884718;

            //Initialize Green Front
            mFrontGreenLat[1] = 32.329803;
            mFrontGreenLat[2] = 32.331045;
            mFrontGreenLat[3] = 32.328407;
            mFrontGreenLat[4] = -32.330262;
            mFrontGreenLat[5] = 32.327435;
            mFrontGreenLat[6] = 32.324812;
            mFrontGreenLat[7] = 32.324447;
            mFrontGreenLat[8] = 32.327239;
            mFrontGreenLat[9] = 32.327574;
            mFrontGreenLat[10] = 32.328724;
            mFrontGreenLat[11] = 32.331519;
            mFrontGreenLat[12] = 32.329939;
            mFrontGreenLat[13] = 32.328498;
            mFrontGreenLat[14] = 32.325569;
            mFrontGreenLat[15] = 32.324521;
            mFrontGreenLat[16] = 32.324317;
            mFrontGreenLat[17] = 32.325244;
            mFrontGreenLat[18] = 32.327788;

            mFrontGreenLong[1] = -110.884399;
            mFrontGreenLong[2] = -110.885062;
            mFrontGreenLong[3] = -110.887627;
            mFrontGreenLong[4] = -110.88988;
            mFrontGreenLong[5] = -110.889879;
            mFrontGreenLong[6] = -110.890764;
            mFrontGreenLong[7] = -110.889366;
            mFrontGreenLong[8] = -110.885212;
            mFrontGreenLong[9] = -110.883048;
            mFrontGreenLong[10] = -110.879328;
            mFrontGreenLong[11] = -110.87874;
            mFrontGreenLong[12] = -110.876943;
            mFrontGreenLong[13] = -110.876715;
            mFrontGreenLong[14] = -110.877641;
            mFrontGreenLong[15] = -110.881362;
            mFrontGreenLong[16] = -110.885338;
            mFrontGreenLong[17] = -110.885587;
            mFrontGreenLong[18] = -110.882062;

            //Initialize Green Mid
            mMidGreenLat[1] = 32.329903;
            mMidGreenLat[2] = 32.331114;
            mMidGreenLat[3] = 32.328403;
            mMidGreenLat[4] = 32.330332;
            mMidGreenLat[5] = 32.327385;
            mMidGreenLat[6] = 32.324715;
            mMidGreenLat[7] = 32.324484;
            mMidGreenLat[8] = 32.327269;
            mMidGreenLat[9] = 32.327596;
            mMidGreenLat[10] = 32.328754;
            mMidGreenLat[11] = 32.331586;
            mMidGreenLat[12] = 32.329862;
            mMidGreenLat[13] = 32.328398;
            mMidGreenLat[14] = 32.325472;
            mMidGreenLat[15] = 32.32445;
            mMidGreenLat[16] = 32.32436;
            mMidGreenLat[17] = 32.325294;
            mMidGreenLat[18] = 32.327845;

            mMidGreenLong[1] = -110.884416;
            mMidGreenLong[2] = -110.885136;
            mMidGreenLong[3] = -110.887727;
            mMidGreenLong[4] = -110.889924;
            mMidGreenLong[5] = -110.889815;
            mMidGreenLong[6] = -110.890752;
            mMidGreenLong[7] = -110.889263;
            mMidGreenLong[8] = -110.885123;
            mMidGreenLong[9] = -110.882961;
            mMidGreenLong[10] = -110.879244;
            mMidGreenLong[11] = -110.87866;
            mMidGreenLong[12] = -110.876961;
            mMidGreenLong[13] = -110.876713;
            mMidGreenLong[14] = -110.877694;
            mMidGreenLong[15] = -110.881449;
            mMidGreenLong[16] = -110.885429;
            mMidGreenLong[17] = -110.885504;
            mMidGreenLong[18] = -110.882072;

            //Initialize Green Rear
            mRearGreenLat[1] = 32.329997;
            mRearGreenLat[2] = 32.331206;
            mRearGreenLat[3] = 32.328407;
            mRearGreenLat[4] = 32.330411;
            mRearGreenLat[5] = 32.327333;
            mRearGreenLat[6] = 32.324621;
            mRearGreenLat[7] = 32.324534;
            mRearGreenLat[8] = 32.32732;
            mRearGreenLat[9] = 32.327631;
            mRearGreenLat[10] = 32.328799;
            mRearGreenLat[11] = 32.331657;
            mRearGreenLat[12] = 32.329781;
            mRearGreenLat[13] = 32.328302;
            mRearGreenLat[14] = 32.325376;
            mRearGreenLat[15] = 32.324379;
            mRearGreenLat[16] = 32.32436;
            mRearGreenLat[17] = 32.325364;
            mRearGreenLat[18] = 32.327908;

            mRearGreenLong[1] = -110.88444;
            mRearGreenLong[2] = -110.885192;
            mRearGreenLong[3] = -110.887825;
            mRearGreenLong[4] = -110.889971;
            mRearGreenLong[5] = -110.889757;
            mRearGreenLong[6] = -110.890741;
            mRearGreenLong[7] = -110.88917;
            mRearGreenLong[8] = -110.885032;
            mRearGreenLong[9] = -110.882874;
            mRearGreenLong[10] = -110.879163;
            mRearGreenLong[11] = -110.878577;
            mRearGreenLong[12] = -110.876989;
            mRearGreenLong[13] = -110.876715;
            mRearGreenLong[14] = -110.877741;
            mRearGreenLong[15] = -110.881528;
            mRearGreenLong[16] = -110.885426;
            mRearGreenLong[17] = -110.885412;
            mRearGreenLong[18] = -110.882065;

        }

    }
}
