﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace H1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class SettingsPage : Page
    {
        public SettingsPage()
        {
            this.InitializeComponent();

            //Initialize
            initializeControls();
        }

        private void initializeControls()
        {
            try
            {
                //Set tab properties
                txtTitle1.IsReadOnly = true;
                txtTitle1.IsTabStop = false;

                txtTitle2.IsReadOnly = true;
                txtTitle2.IsTabStop = false;

                txtTitle3.IsReadOnly = true;
                txtTitle3.IsTabStop = false;

                txtTitle4.IsReadOnly = true;
                txtTitle4.IsTabStop = false;

                txtTitle5.IsReadOnly = true;
                txtTitle5.IsTabStop = false;

                txtTitle6.IsReadOnly = true;
                txtTitle6.IsTabStop = false;

                txtTitle7.IsReadOnly = true;
                txtTitle7.IsTabStop = false;

                rbHaversine.TabIndex = 0;
                rbSphericalLawofCosines.TabIndex = 1;
                rbSphericalEarthProjection.TabIndex = 2;

                btnClose.TabIndex = 3;

                //Select formula radio button
                if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.Haversine)
                {
                    rbHaversine.IsChecked = true;
                }
                else if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.SphericalLawCosines)
                {
                    rbSphericalLawofCosines.IsChecked = true;
                }
                else if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.SphericalEarthProjection)
                {
                    rbSphericalEarthProjection.IsChecked = true;
                }

            }
            catch
            {
                //blank
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.Frame.Navigate(typeof(MainPage));

            }
            catch
            {
                //blank
            }
        }

        private void btnFormulaChangeConfirm_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (rbHaversine.IsChecked == true)
                {
                    cGeo.DistanceFormula = cGeo.enumDistanceFormula.Haversine;

                }
                else if (rbSphericalLawofCosines.IsChecked == true)
                {
                    cGeo.DistanceFormula = cGeo.enumDistanceFormula.SphericalLawCosines;

                }
                else if (rbSphericalEarthProjection.IsChecked == true)
                {
                    cGeo.DistanceFormula = cGeo.enumDistanceFormula.SphericalEarthProjection;

                }

            }
            catch
            {
                //blank
            }
        }

        private void btnFormulaChangeCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Return selection to formula radio button
                if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.Haversine)
                {
                    rbHaversine.IsChecked = true;
                }
                else if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.SphericalLawCosines)
                {
                    rbSphericalLawofCosines.IsChecked = true;
                }
                else if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.SphericalEarthProjection)
                {
                    rbSphericalEarthProjection.IsChecked = true;
                }

            }
            catch
            {
                //blank
            }
        }
    }
}
