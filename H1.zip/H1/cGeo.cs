﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H1
{
    class cGeo
    {
        public enum enumDistanceFormula
        {
            Haversine = 1, SphericalLawCosines, SphericalEarthProjection
        };

        //For spherical distance math
        private const double _radiusEarthMiles = 3959;
        private const double _radiusEarthKM = 6371;
        private const double _m2km = 1.60934;
        private const double _toRad = Math.PI / 180;

        public static enumDistanceFormula DistanceFormula = enumDistanceFormula.SphericalLawCosines;

        //For GPS object
        public static bool DataValid;
        public static int UpdateCount;

        public static DateTime GpsTimeStamp;
        public static double LatitudeDegrees;
        public static double LongitudeDegrees;
        public static double GpsSpeed;
        public static double GpsCourse;
        public static double GpsAltitude;
        public static string GpsAltitudeUnits;
        public static int SatelliteCount;
        public static string LatHemisphere;
        public static string LongHemisphere;


        //Haversine formula to calculate 
        //Great-circle (orthodromic) distance on Earth 
        //High Accuracy, Medium speed
        public static double DistanceMilesHaversine(double Lat1, double Lon1, double Lat2, double Lon2)
        {
            try
            {
                double _radLat1 = Lat1 * _toRad;
                double _radLat2 = Lat2 * _toRad;
                double _dLatHalf = (_radLat2 - _radLat1) / 2;
                double _dLonHalf = Math.PI * (Lon2 - Lon1) / 360;

                //Intermediate result
                double _a = Math.Sin(_dLatHalf);
                _a *= _a;

                //Intermediate result
                double _b = Math.Sin(_dLonHalf);
                _b *= _b * Math.Cos(_radLat1) * Math.Cos(_radLat2);

                //Central angle, aka arc segment angular distance
                double _centralAngle = 2 * Math.Atan2(Math.Sqrt(_a + _b), Math.Sqrt(1 - _a - _b));

                //Great-Circle (orthodromic) distance on Earth between 2 points
                return _radiusEarthMiles * _centralAngle;
            }
            catch { throw; }
        }

        //Spherical law of cosines formula to calculate great-circle distance between two points on Earth
        //Spherical Law of Cosines formula to calculate 
        //Great-Circle (orthodromic) distance on Earth
        //High Accuracy, Medium speed
        //http://en.wikipedia.org/wiki/Spherical_law_of_cosines
        public static double DistanceMilesSLC(double Lat1, double Lon1, double Lat2, double Lon2)
        {
            try
            {
                double _radLat1 = Lat1 * _toRad;
                double _radLat2 = Lat2 * _toRad;
                double _radLon1 = Lon1 * _toRad;
                double _radLon2 = Lon2 * _toRad;

                //Central angle, aka arc segment angular distance
                double _centralAngle = Math.Acos(Math.Sin(_radLat1) * Math.Sin(_radLat2) +
                        Math.Cos(_radLat1) * Math.Cos(_radLat2) * Math.Cos(_radLon2 - _radLon1));

                //Great-Circle (orthodromic) distance on Earth between 2 points
                return _radiusEarthMiles * _centralAngle;
            }
            catch { throw; }
        }

        //Great-circle distance calculation using Spherical Earth projection formula**
        //Spherical Earth projection to a plane formula (using Pythagorean Theorem) to calculate great-circle (orthodromic) distance on Earth
        //http://en.wikipedia.org/wiki/Geographical_distance
        //central angle = Sqrt((_radLat2 - _radLat1)^2 + (Cos((_radLat1 + _radLat2)/2) * (Lon2 - Lon1))^2)
        //Medium Accuracy, Fast,
        //Relative error less than 0.1% in search area smaller than 250 miles
        public static double DistanceMilesSEP(double Lat1, double Lon1, double Lat2, double Lon2)
        {
            try
            {
                double _radLat1 = Lat1 * _toRad;
                double _radLat2 = Lat2 * _toRad;
                double _dLat = (_radLat2 - _radLat1);
                double _dLon = (Lon2 - Lon1) * _toRad;

                double _a = (_dLon) * Math.Cos((_radLat1 + _radLat2) / 2);

                //Central angle, aka arc segment angular distance
                double _centralAngle = Math.Sqrt(_a * _a + _dLat * _dLat);

                //Great-Circle (orthodromic) distance on Earth between 2 points
                return _radiusEarthMiles * _centralAngle;
            }
            catch { throw; }
        }

        public static bool parseCommaStringToDouble(string str, ref double dLatRet, ref double dLongRet)
        {
            try
            {
                double dTemp;
                string[] sLines;

                //Initialize
                sLines = str.Split(',');

                //Convert latitude to double
                if (double.TryParse(sLines[0], out dTemp) == false)
                {
                    return false;
                }

                dLatRet = dTemp;

                //Convert longitude to double
                if (double.TryParse(sLines[1], out dTemp) == false)
                {
                    return false;
                }

                dLongRet = dTemp;

                //If we make it here, all is good
                return true;
            }
            catch
            {
                throw;

            }
        }

        public static double degreesToRadians(double dAngle)
        {
            try
            {

                return dAngle * (Math.PI / 180);

            }
            catch
            {
                throw;

            }
        }

        public static double radiansToDegrees(double dRadians)
        {
            try
            {

                return dRadians * (180 / Math.PI);

            }
            catch
            {
                throw;

            }
        }

        public static double kilometersToYards(double dVal)
        {
            try
            {

                return (dVal / 0.000914);

            }
            catch
            {
                throw;

            }
        }

        public static double yardsToKilometers(double dVal)
        {
            try
            {

                return (dVal * 0.000914);

            }
            catch
            {
                throw;

            }
        }

    }
}
