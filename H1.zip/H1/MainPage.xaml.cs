﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace H1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {

        public MainPage()
        {
            this.InitializeComponent();

            //Ensure page remains loaded
            this.NavigationCacheMode = NavigationCacheMode.Required;

            //Initialize GPS object
            mGPS = new AdafruitClassLibrary.Gps();

            mGPS.RMCEvent += MGPS_RMCEvent;
            mGPS.GGAEvent += MGPS_GGAEvent;

            //Initialize timer object
            mTimer = new DispatcherTimer();
            mTimer.Interval = TimeSpan.FromMilliseconds(1000);
            mTimer.Tick += Timer_Tick;

            //Initialize everything else
            mSLCC = new cSkylineCountryClub();
            initializeControls();
            txtStatus.Background = new SolidColorBrush(Windows.UI.Colors.Red);

            postMessage("Application started");

        }


        //Module scoped variables
        private AdafruitClassLibrary.Gps mGPS;
        private cSkylineCountryClub mSLCC;
        private DispatcherTimer mTimer;


        //Constants
        private const string TIME_FORMAT = "HH:mm:ss.fff";
        private const string DATE_FORMAT = "dd-MMM-yyyy";
        private const string INV_MESSAGE = "invalid";
        private const string DBL_SIG_DIG = "0#.00";
        private const int MILES_TO_YARDS_MULT = 1760;


        private void postMessage(string sMsg)
        {
            sMsg += string.Format(" {0}", System.DateTime.Now);
            lstMessages.Items.Insert(0, sMsg);

        }

        private void initializeControls()
        {
            try
            {
                txtDistanceFormula.Text = cGeo.DistanceFormula.ToString();

                txtUpdates.IsReadOnly = true;
                txtUpdates.IsTabStop = false;

                txtStatus.IsReadOnly = true;
                txtStatus.IsTabStop = false;

                txtHoleTitle.IsReadOnly = true;
                txtHoleTitle.IsTabStop = false;

                txtDistanceFormula.IsReadOnly = true;
                txtDistanceFormula.IsTabStop = false;

                txtStatus.IsReadOnly = true;
                txtStatus.IsTabStop = false;

                txtFrontGreenLocation.IsReadOnly = true;
                txtFrontGreenLocation.IsTabStop = false;

                txtCenterGreenLocation.IsReadOnly = true;
                txtCenterGreenLocation.IsTabStop = false;

                txtRearGreenLocation.IsReadOnly = true;
                txtRearGreenLocation.IsTabStop = false;

                txtGPSLocation.IsReadOnly = true;
                txtGPSLocation.IsTabStop = false;

                txtTeeLocation.IsReadOnly = true;
                txtTeeLocation.IsTabStop = false;

                txtGpsToFrontGreenLocation.IsReadOnly = true;
                txtGpsToFrontGreenLocation.IsTabStop = false;

                txtGpsToCenterGreenLocation.IsReadOnly = true;
                txtGpsToCenterGreenLocation.IsTabStop = false;

                txtGpsToRearGreenLocation.IsReadOnly = true;
                txtGpsToRearGreenLocation.IsTabStop = false;

                txtTeeToFrontGreenDistance.IsReadOnly = true;
                txtTeeToFrontGreenDistance.IsTabStop = false;

                txtTeeToCenterGreenDistance.IsReadOnly = true;
                txtTeeToCenterGreenDistance.IsTabStop = false;

                txtTeeToRearGreenDistance.IsReadOnly = true;
                txtTeeToRearGreenDistance.IsTabStop = false;

                txtTitle1.IsReadOnly = true;
                txtTitle1.IsTabStop = false;

                txtTitle2.IsReadOnly = true;
                txtTitle2.IsTabStop = false;

                txtTitle3.IsReadOnly = true;
                txtTitle3.IsTabStop = false;

                txtTitle4.IsReadOnly = true;
                txtTitle4.IsTabStop = false;

                txtTitle5.IsReadOnly = true;
                txtTitle5.IsTabStop = false;

                txtTitle6.IsReadOnly = true;
                txtTitle6.IsTabStop = false;

                txtTitle7.IsReadOnly = true;
                txtTitle7.IsTabStop = false;

                txtTitle8.IsReadOnly = true;
                txtTitle8.IsTabStop = false;

                txtTitle9.IsReadOnly = true;
                txtTitle9.IsTabStop = false;

                lstMessages.IsTabStop = false;

                btnStart.TabIndex = 0;
                btnStop.TabIndex = 1;
                btnSettings.TabIndex = 2;
                btnClose.TabIndex = 3;

                rbHole1.TabIndex = 4;
                rbHole2.TabIndex = 5;
                rbHole3.TabIndex = 6;
                rbHole4.TabIndex = 7;
                rbHole5.TabIndex = 8;
                rbHole6.TabIndex = 9;
                rbHole7.TabIndex = 10;
                rbHole8.TabIndex = 11;
                rbHole9.TabIndex = 12;
                rbHole10.TabIndex = 13;
                rbHole11.TabIndex = 14;
                rbHole12.TabIndex = 15;
                rbHole13.TabIndex = 16;
                rbHole14.TabIndex = 17;
                rbHole15.TabIndex = 18;
                rbHole16.TabIndex = 19;
                rbHole17.TabIndex = 20;
                rbHole18.TabIndex = 21;

            }
            catch (Exception ex)
            {
                postMessage(string.Format("initializeControls: {0}", ex.Message));

            }
        }

        private async void startGPS()
        {
            try
            {
                //See note below about changing baud rates

                await mGPS.ConnectToUARTAsync(9600);

                if (mGPS.Connected == true)
                {
                    await mGPS.SetSentencesReportingAsync(0, 1, 0, 1, 0, 0);
                    await mGPS.SetUpdateFrequencyAsync(1);  //1Hz. Change to 5 for 5Hz. Change to 10 for 10Hz. Change to 0.1 for 0.1Hz
                    mGPS.StartReading();
                    mTimer.Start();
                    
                    postMessage("GPS device init and read successful");

                }
                else
                {
                    postMessage("GPS device not successful");

                }

            }
            catch (Exception ex)
            {
                postMessage(string.Format("startGPS: {0}", ex.Message));

            }
        }

        private void stopGPS()
        {
            try
            {
                mGPS.StopReading();
                mGPS.DisconnectFromUART();
                mTimer.Stop();

                postMessage("GPS device stop successful");

            }
            catch (Exception ex)
            {
                postMessage(string.Format("stopGPS: {0}", ex.Message));

            }
        }

        private void calculateDistances2()
        {
            try
            {
                int iSelectedHole;
                 double dTemp;

                //Initialize
                iSelectedHole = whatHoleAmIon();
                
                //Fill-in text boxes with GPS data
                txtFrontGreenLocation.Text = string.Format("{0:0#.00000}, {1:0#.00000}", mSLCC.mFrontGreenLat[iSelectedHole], mSLCC.mFrontGreenLong[iSelectedHole]);
                txtCenterGreenLocation.Text = string.Format("{0:0#.00000}, {1:0#.00000}", mSLCC.mMidGreenLat[iSelectedHole], mSLCC.mMidGreenLong[iSelectedHole]);
                txtRearGreenLocation.Text = string.Format("{0:0#.00000}, {1:0#.00000}", mSLCC.mRearGreenLat[iSelectedHole], mSLCC.mRearGreenLong[iSelectedHole]);

                txtTeeLocation.Text = string.Format("{0:0#.00000}, {1:0#.00000}", mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole]);
                txtGPSLocation.Text = string.Format("{0:0#.00000}, {1:0#.00000}", cGeo.LatitudeDegrees, cGeo.LongitudeDegrees);

                //Fill-in text boxes with distances
                if (cGeo.DistanceFormula  == cGeo.enumDistanceFormula.Haversine)
                {
                    dTemp = cGeo.DistanceMilesHaversine(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mFrontGreenLat[iSelectedHole], mSLCC.mFrontGreenLong[iSelectedHole]);
                    txtGpsToFrontGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesHaversine(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mMidGreenLat[iSelectedHole], mSLCC.mMidGreenLong[iSelectedHole]);
                    txtGpsToCenterGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesHaversine(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mRearGreenLat[iSelectedHole], mSLCC.mRearGreenLong[iSelectedHole]);
                    txtGpsToRearGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesHaversine(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mFrontGreenLat[iSelectedHole], mSLCC.mFrontGreenLong[iSelectedHole]);
                    txtTeeToFrontGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesHaversine(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mMidGreenLat[iSelectedHole], mSLCC.mMidGreenLong[iSelectedHole]);
                    txtTeeToCenterGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesHaversine(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mRearGreenLat[iSelectedHole], mSLCC.mRearGreenLong[iSelectedHole]);
                    txtTeeToRearGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                }
                else if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.SphericalEarthProjection)
                {
                    dTemp = cGeo.DistanceMilesSEP(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mFrontGreenLat[iSelectedHole], mSLCC.mFrontGreenLong[iSelectedHole]);
                    txtGpsToFrontGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSEP(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mMidGreenLat[iSelectedHole], mSLCC.mMidGreenLong[iSelectedHole]);
                    txtGpsToCenterGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSEP(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mRearGreenLat[iSelectedHole], mSLCC.mRearGreenLong[iSelectedHole]);
                    txtGpsToRearGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSEP(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mFrontGreenLat[iSelectedHole], mSLCC.mFrontGreenLong[iSelectedHole]);
                    txtTeeToFrontGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSEP(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mMidGreenLat[iSelectedHole], mSLCC.mMidGreenLong[iSelectedHole]);
                    txtTeeToCenterGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSEP(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mRearGreenLat[iSelectedHole], mSLCC.mRearGreenLong[iSelectedHole]);
                    txtTeeToRearGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                }
                else if (cGeo.DistanceFormula == cGeo.enumDistanceFormula.SphericalLawCosines)
                {
                    dTemp = cGeo.DistanceMilesSLC(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mFrontGreenLat[iSelectedHole], mSLCC.mFrontGreenLong[iSelectedHole]);
                    txtGpsToFrontGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSLC(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mMidGreenLat[iSelectedHole], mSLCC.mMidGreenLong[iSelectedHole]);
                    txtGpsToCenterGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSLC(cGeo.LatitudeDegrees, cGeo.LongitudeDegrees, mSLCC.mRearGreenLat[iSelectedHole], mSLCC.mRearGreenLong[iSelectedHole]);
                    txtGpsToRearGreenLocation.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSLC(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mFrontGreenLat[iSelectedHole], mSLCC.mFrontGreenLong[iSelectedHole]);
                    txtTeeToFrontGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSLC(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mMidGreenLat[iSelectedHole], mSLCC.mMidGreenLong[iSelectedHole]);
                    txtTeeToCenterGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                    dTemp = cGeo.DistanceMilesSLC(mSLCC.mBlueTeesLat[iSelectedHole], mSLCC.mBlueTeesLong[iSelectedHole], mSLCC.mRearGreenLat[iSelectedHole], mSLCC.mRearGreenLong[iSelectedHole]);
                    txtTeeToRearGreenDistance.Text = (dTemp * MILES_TO_YARDS_MULT).ToString(DBL_SIG_DIG);

                }

                //Updates
                txtUpdates.Text = cGeo.UpdateCount.ToString();
                txtHoleTitle.Text = string.Format("Distances for Hole {0}", iSelectedHole);

            }
            catch (Exception ex)
            {
                postMessage(string.Format("calculateDistances2: {0}", ex.Message));

            }
        }

        private int whatHoleAmIon()
        {
            try
            {
                int iHole = 1;

                if (rbHole1.IsChecked == true)
                {
                    iHole = 1;
                }
                else if (rbHole2.IsChecked == true)
                {
                    iHole = 2;
                }
                else if (rbHole3.IsChecked == true)
                {
                    iHole = 3;
                }
                else if (rbHole4.IsChecked == true)
                {
                    iHole = 4;
                }
                else if (rbHole5.IsChecked == true)
                {
                    iHole = 5;
                }
                else if (rbHole6.IsChecked == true)
                {
                    iHole = 6;
                }
                else if (rbHole7.IsChecked == true)
                {
                    iHole = 7;
                }
                else if (rbHole8.IsChecked == true)
                {
                    iHole = 8;
                }
                else if (rbHole9.IsChecked == true)
                {
                    iHole = 9;
                }
                else if (rbHole10.IsChecked == true)
                {
                    iHole = 10;
                }
                else if (rbHole11.IsChecked == true)
                {
                    iHole = 11;
                }
                else if (rbHole12.IsChecked == true)
                {
                    iHole = 12;
                }
                else if (rbHole13.IsChecked == true)
                {
                    iHole = 13;
                }
                else if (rbHole14.IsChecked == true)
                {
                    iHole = 14;
                }
                else if (rbHole15.IsChecked == true)
                {
                    iHole = 15;
                }
                else if (rbHole16.IsChecked == true)
                {
                    iHole = 16;
                }
                else if (rbHole17.IsChecked == true)
                {
                    iHole = 17;
                }
                else if (rbHole18.IsChecked == true)
                {
                    iHole = 18;
                }
                else
                {
                    iHole = 1;
                }

                return iHole;

            }
            catch (Exception ex)
            {
                postMessage(string.Format("whatHoleAmIon: {0}", ex.Message));
                return 1;

            }
        }

        private void MGPS_GGAEvent(object sender, AdafruitClassLibrary.Gps.GPSGGA e)
        {
            try
            {
                if (e.Quality != AdafruitClassLibrary.Gps.GPSGGA.FixQuality.noFix)
                {
                    cGeo.GpsAltitude = (double) e.Altitude;
                    cGeo.SatelliteCount = (int)e.Satellites;
                    cGeo.GpsAltitudeUnits = e.AltUnits;

                    cGeo.UpdateCount = ++cGeo.UpdateCount % 1000;

                }
                else
                {
                    cGeo.GpsAltitude = -1.0;
                    cGeo.SatelliteCount = -1;
                    cGeo.GpsAltitudeUnits = "";

                }

            }
            catch (Exception ex)
            {
                postMessage(string.Format("MGPS_GGAEvent: {0}", ex.Message));

            }
        }

        private void MGPS_RMCEvent(object sender, AdafruitClassLibrary.Gps.GPSRMC e)
        {
            try
            {
                if (e.Valid)
                {
                    cGeo.LatitudeDegrees = (double)e.LatDegrees;
                    cGeo.LongitudeDegrees = (double)e.LonDegrees;
                    cGeo.GpsTimeStamp = e.TimeStamp;
                    cGeo.GpsSpeed = (double)e.Speed;
                    cGeo.GpsCourse = (double)e.Course;

                    cGeo.LatHemisphere = e.LatHemisphere;
                    cGeo.LongHemisphere = e.LonHemisphere;

                    if (e.LatHemisphere.ToLower() == "s")
                    {
                        cGeo.LatitudeDegrees = cGeo.LatitudeDegrees * -1;
                    }

                    if (e.LonHemisphere.ToLower() == "w")
                    {
                        cGeo.LongitudeDegrees = cGeo.LongitudeDegrees * -1;
                    }

                    cGeo.UpdateCount = ++cGeo.UpdateCount % 1000;

                }
                else
                {
                    cGeo.LatitudeDegrees = -1.0;
                    cGeo.LongitudeDegrees = -1.0;
                    cGeo.GpsTimeStamp = new DateTime(1995, 4, 9);
                    cGeo.GpsSpeed = -1.0;
                    cGeo.GpsCourse = -1.0;

                    cGeo.LatHemisphere = "";
                    cGeo.LongHemisphere = "";

                }

                cGeo.DataValid = e.Valid;

            }
            catch (Exception ex)
            {
                postMessage(string.Format("MGPS_RMCEvent: {0}", ex.Message));

            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Application.Current.Exit();

            }
            catch (Exception ex)
            {
                postMessage(string.Format("btnClose_Click: {0}", ex.Message));

            }
        }

        private void btnSettings_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.Frame.Navigate(typeof(SettingsPage));

            }
            catch (Exception ex)
            {
                postMessage(string.Format("btnSettings_Click: {0}", ex.Message));

            }
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                txtStatus.Text = "Running";
                txtStatus.Background = new SolidColorBrush(Windows.UI.Colors.LimeGreen);

                startGPS();

            }
            catch (Exception ex)
            {
                postMessage(string.Format("btnStart_Click: {0}", ex.Message));

            }
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //todo: could not make this code work. It hangs the app
                //and requires the process be forcibly killed

                //txtStatus.Text = "Stopped";
                //txtStatus.Background = new SolidColorBrush(Windows.UI.Colors.Red);
                //stopGPS();

            }
            catch (Exception ex)
            {
                postMessage(string.Format("btnStop_Click: {0}", ex.Message));

            }
        }

        private void Timer_Tick(object sender, object e)
        {
            try
            {
                if (cGeo.DataValid == true)
                {
                    calculateDistances2();
                }

                txtDistanceFormula.Text = cGeo.DistanceFormula.ToString();

            }
            catch (Exception ex)
            {
                postMessage(string.Format("Timer_Tick: {0}", ex.Message));

            }
        }
    }
}
